import React, {useState} from 'react'
import English from './../../packs/languages'
let lan = Language.English 
import {View, Text, TouchableOpacity,StyleSheet} from 'react-native'
import Language from './../../packs/languages'
const Login = () =>{
    
    return (
        <View style={Loginstyle.root}>
              dick
        </View>
    )
}
export default Login
const Loginstyle = StyleSheet.create({
    root :{
        width:"100%",
        height:"100%",
        backgroundColor:"#141923"
    }
})