import React from 'react'
import {View, Text} from 'react-native'
const SignUp = () => {
    return (
        <View> 
            <Text>this is a sign in page </Text>
        </View>
    )
}